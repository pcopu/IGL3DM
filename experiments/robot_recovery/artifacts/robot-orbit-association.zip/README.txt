IGL3DM broad-view association evidence: robot.
All actual predictions, wrong and unresolved identities, source snapshots and failed variants are retained.
Control geometry is EVALUATION ONLY. It is never the target robot reference.
The pear control input video/truth are in the preceding public robot-physical-identity-audit.zip.
The robot input is the preceding public robot-reproducibility.zip; its normalized frames follow the repository's shared transform.
New independent controls include exact48-frame FFV1 AVI input and full synthetic evaluation truth.
Known cameras are declared control acquisition metadata. Robot camera estimates are experimental.
Missing measurements and surfaces are not synthesized. These are research candidates, not validated assets.
Duplicate bytes are stored once; ALIASES.json preserves every logical path. Run restore_aliases.py after extraction if full paths are needed.
