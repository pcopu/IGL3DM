from pathlib import Path
import json,sys,hashlib
root=Path(__file__).resolve().parent;src=root.parent/'source/experiments/marker_consistency/source';sys.path.insert(0,str(src))
text=(root/'fit_variable_orbit_robot.py').read_text();old="r=least_squares(objective,x0,bounds=(low,high),loss='soft_l1',f_scale=1,max_nfev=200,ftol=1e-8,xtol=1e-8,gtol=1e-8)";new="r=least_squares(objective,x0,bounds=(low,high),loss='soft_l1',f_scale=1,max_nfev=500,ftol=1e-8,xtol=1e-8,gtol=1e-8,jac='3-point',diff_step=1e-4,x_scale='jac')";assert text.count(old)==1;text=text.replace(old,new)
copy=root/'fit_variable_orbit_solver_check.py';copy.write_text(text)
protocol={'trial':'One central-difference numerical solver comparison, not a new camera model.','jac':'3-point','diff_step':1e-4,'x_scale':'jac','max_nfev':500,'unchanged':['five knots','8parameter model','data and deterministic split','initial parameter vector','speed bounds0.01to5.625','regularization','geometry gates'],'selection_basis':'Calibration objective/derivative behavior and controls, not heldout error or mesh density.','source_sha256':hashlib.sha256((root/'fit_variable_orbit_robot.py').read_bytes()).hexdigest()};(root/'recovery-solver-protocol.json').write_text(json.dumps(protocol,indent=2))
ns={'__file__':str(src/'fit_variable_orbit.py'),'__name__':'solver_check'};exec(compile(text,str(copy),'exec'),ns)
r=ns['fit'](json.loads((root/'grid_tracks/graph_joint_cycle_veto/tracks.json').read_text()),json.loads((root/'grid_input/video_manifest.json').read_text()),json.loads((root/'grid_constant_camera.json').read_text()));r['solver_protocol']=protocol
(root/'recovery_camera_solver.json').write_text(json.dumps(r,indent=2))
print(json.dumps({k:r[k] for k in ['optimizer_success','optimizer_message','nfev','optimizer_cost','optimizer_optimality','calibration_after_px','scaled_robust_jacobian_condition']},indent=2));print('heldout',{k:v for k,v in r['validation'].items() if k not in ['tracks','paired_observations']})
