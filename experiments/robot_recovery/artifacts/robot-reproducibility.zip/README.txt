IGL3DM ROBOT: ACTUAL GRID-MATH RECONSTRUCTION

This is not the silhouette baseline. It uses the delivered Kling video only.

Pipeline
1. Decode 193 native video frames; one shared affine transform to 512 square.
2. Re-detect ink junctions and closed grid cells in every frame. RootSIFT descriptors, reciprocal optical flow, one-to-one assignment, neighbor support and skip-cycle conflict rejection build contiguous track fragments. No hidden-point or gap reconnection.
3. Fit restricted constant-speed cameras, then one declared five-knot variable-speed extension allowing near-pauses. Original source unchanged. Of 601 long fragments, 462 fit the camera and 139 are held out by deterministic ID hash.
4. Fit each heldout point from its middle-half observations; predict endpoint quarters. Across 2,204 endpoint observations, p95 improves 10.20 to 2.23 analysis pixels. Identity and camera are not thereby proven.
5. Keep points with training and endpoint p95 <= 1 pixel, rank 3, condition <= 20, at least 9 observations and 30 degrees fitted yaw span. Assemble only four-corner cells observed in at least 3 frames.

RESULT: 199 candidate points, 16 observed quads using 46 vertices. This is sparse partial geometry, not a complete reconstructed character. No surface completion, silhouette geometry, reference-generator mesh, neural prior or new paid generation was used. Constant-speed estimated cameras yielded 59 points / 2 quads.

FILES
robot-grid-geometry.png: three actual geometry views.
robot-grid-geometry-turntable.gif: display rotation of those exact points/faces.
robot-grid-tracking-evidence.png: actual source frames and detected/selected nodes.
robot-grid-candidates.glb: actual points plus triangulated observed quads; some viewers omit point primitives.
robot-grid-candidates.ply: all 199 vertices and 16 original quad faces.
metrics.json: honest unselected holdout errors, temporal breakdown, limitations and tests.
evidence/: measured tracks, observed connectivity, camera matrices, gating audit and reproducibility sources.

Important: the inferred sweep is 345.92 degrees, not validated 360 degree closure. No track survives the entire orbit. Repeating grid identities can be coherently wrong, and fragment-level holdout can share an unknown physical point across splits. Variable speed improves image prediction but worsens conditioning near pauses. A 1 pixel gate on this analysis is 2.5 native video pixels. Low selected residuals do not imply calibrated 3D accuracy. The one variable-speed fit terminated on its step-size criterion with optimality 219.68, not a verified stationary optimum; no further tuning was performed. Of 199 points, 118 came from camera-training fragments, 41 from camera-heldout fragments and 40 from shorter fragments.

49 classical/video-grid regression tests and both graph structural validators pass. Source fit/association algorithms and strict thresholds were preserved; one task-local extension changed the variable-speed lower bound from 1.875 to 0.01 degrees/frame because this input has endpoint holds. Five knots and other settings were not tuned against heldout results. The official PyPI packages were installed in a task-only folder with user approval.
