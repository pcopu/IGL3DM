from pathlib import Path
import json,sys,importlib.util,hashlib
import numpy as np
root=Path(__file__).resolve().parent;src=root.parent/'source/experiments/marker_consistency/source';sys.path.insert(0,str(src))
import fit_shared_orbit as constant
import fit_variable_orbit as variable
from build_graph_geometry import build
tracks=root/'grid_tracks/graph_joint_cycle_veto/tracks.json';graphs=root/'grid_tracks/frame_graphs.json';frames=np.arange(193)
for label in ['constant','variable']:
 report=json.loads((root/f'grid_{label}_camera.json').read_text());params=np.array(report['parameter_vector'])
 if label=='constant':
  A,b=constant.design(frames,params);yaw=frames*360/np.exp(params[0])
 else:
  A,b=variable.design(frames,params,report['domain_samples']);yaw=np.rad2deg(variable.yaw(frames,params,report['domain_samples']))
 out={'status':'Experimental camera estimate, unaccepted calibration','coordinates':'Uniform native to512square: scale0.4,x_offset112; Z-up relative world with256pixel/unit gauge, not physical units.','source_report_sha256':hashlib.sha256((root/f'grid_{label}_camera.json').read_bytes()).hexdigest(),'views':[{'sample_index':int(i),'yaw_deg':float(y),'orthographic_projection_2x4_normalized512':np.c_[a,b].tolist()} for i,y,a in zip(frames,yaw,A)]}
 camera=root/f'grid_{label}_projections.json';camera.write_text(json.dumps(out,indent=2))
 print(label,json.dumps(build(tracks,graphs,camera,root/f'grid_geometry_{label}'),indent=2))
# Shape diagnostics reuse the repository function, but graph-builder faces all already pass its conditional gate.
spec=importlib.util.spec_from_file_location('shape_audit',root.parent/'source/experiments/video_grid/audit_quad_shape.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
for label in ['constant','variable']:
 folder=root/f'grid_geometry_{label}';pp=json.loads((folder/'candidate_points.json').read_text());ff=json.loads((folder/'candidate_faces.json').read_text());r=audit.audit(np.asarray([p['xyz'] for p in pp]),[f['point_indices'] for f in ff],[True]*len(ff));(folder/'quad_shape_diagnostic.json').write_text(json.dumps(r,indent=2));print(label,'shape',r)
