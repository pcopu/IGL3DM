"""One predeclared robot-specific speed-bound extension; existing math otherwise unchanged."""
from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
source=root.parent/'source/experiments/marker_consistency/source/fit_variable_orbit.py'
text=source.read_text();old='np.full(N_KNOTS,np.log(2*np.pi/192))';new='np.full(N_KNOTS,np.log(np.deg2rad(0.01)))'
assert text.count(old)==1
text=text.replace(old,new).replace("'knot_speed_deg_per_frame':[360/192,360/64]", "'knot_speed_deg_per_frame':[0.01,360/64]")
copy=root/'fit_variable_orbit_robot.py';copy.write_text(text)
protocol={'basis':'Unchanged five-log-speed-knot fit with only lower speed bound extended for the robot video endpoint hold.','lower_speed_deg_per_frame':0.01,'upper_speed_deg_per_frame':360/64,'n_knots':5,'minimum_samples':16,'holdout':'sha256(track_id) % 5 == 0 unchanged; never fit camera to heldout IDs','fixed_gate':'middle half point fit; endpoint quarter prediction; p95 <= 1 square pixel in each; rank3; condition<=20; yaw span>=30degrees','trials':1,'parent_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'task_copy_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'no_truth_or_reference_geometry':True,'source_repository_edited':False,'limitations':['Strictly positive0.01degree floor approximates rather than represents exact holds.','Five knots cannot describe abrupt starts/stops exactly.','Camera fitting and residual selection do not authenticate periodic grid identities.','No heldout-driven tuning or model selection.']}
(root/'variable-camera-protocol.json').write_text(json.dumps(protocol,indent=2))
sys.path.insert(0,str(source.parent))
namespace={'__file__':str(source),'__name__':'robot_variable_extension'}
exec(compile(text,str(copy),'exec'),namespace)
tracks=json.loads((root/'grid_tracks/graph_joint_cycle_veto/tracks.json').read_text());manifest=json.loads((root/'grid_input/video_manifest.json').read_text());baseline=json.loads((root/'grid_constant_camera.json').read_text())
report=namespace['fit'](tracks,manifest,baseline)
report['input_paths']={'tracks':str(root/'grid_tracks/graph_joint_cycle_veto/tracks.json'),'manifest':str(root/'grid_input/video_manifest.json'),'baseline':str(root/'grid_constant_camera.json')}
report['task_extension']=protocol
(root/'grid_variable_camera.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:report[k] for k in ['optimizer_success','nfev','camera','calibration_track_count','validation_track_count','calibration_before_px','calibration_after_px','bounds']},indent=2))
print('HELDOUT',json.dumps({k:v for k,v in report['validation'].items() if k not in ['tracks','paired_observations']},indent=2))
