from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
for target,source in json.loads((r/'ALIASES.json').read_text()).items():
 a=(r/target).resolve();b=(r/source).resolve()
 if not a.is_relative_to(r) or not b.is_relative_to(r):raise ValueError('Unsafe alias')
 data=b.read_bytes()
 if a.exists() and a.read_bytes()!=data:raise ValueError('Conflicting file')
 a.parent.mkdir(parents=True,exist_ok=True);a.write_bytes(data)
for name,meta in json.loads((r/'MANIFEST.json').read_text()).items():
 p=(r/name).resolve()
 if not p.is_relative_to(r) or hashlib.sha256(p.read_bytes()).hexdigest()!=meta['sha256']:raise ValueError('Hash mismatch')
print('All logical evidence files restored and verified')
