from pathlib import Path
import json
r=Path(__file__).resolve().parent
for target,source in json.loads((r/'ALIASES.json').read_text()).items():
 a=(r/target).resolve();b=(r/source).resolve()
 if not a.is_relative_to(r) or not b.is_relative_to(r):raise ValueError('Unsafe alias path')
 data=b.read_bytes()
 if a.exists() and a.read_bytes()!=data:raise ValueError('Refusing conflicting existing file')
 a.parent.mkdir(parents=True,exist_ok=True);a.write_bytes(data)
print('Restored identical evidence aliases')
