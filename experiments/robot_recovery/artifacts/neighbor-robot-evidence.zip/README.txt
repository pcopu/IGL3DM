IGL3DM endpoint-support checkpoint: robot.
Experimental sparse measured geometry only. All rejected decisions and original withheld predictions are retained.
Control truth is evaluation-only, never target reference geometry.
Original pear/bent/barrel inputs and broad-view hypotheses are in the preceding public orbit evidence archives. Robot input is the preceding robot-reproducibility archive; base association is robot-orbit-association.zip.
The fourth warped-waist input is exact48-frame FFV1 AVI, with96-view evaluation-only truth.
Initial and final variants have identical XYZ, observations and intervals; final variants correct metadata provenance and input guards.
The primary variant preserves XYZ; refit uses retained calibration observations only.
Local workspace prefixes in textual logs are normalized to <workspace> during packaging.
Byte-identical repeated files use explicit aliases. Run restore_aliases.py after extraction; verify MANIFEST.json.
