IGL3DM physical-identity checkpoint, 2026-11-12.
Truth is evaluation-only and belongs to a distinct synthetic control, never the robot target.
The source controls were rendered before this experiment. The control96 FFV1 AVI decodes pixel-identically to all 96 original images.
The control48 sequence uses every second original frame; its input verification and full measurements are retained.
Use the previous public robot-reproducibility.zip for the exact robot input and original detector/tracker sources from the repository.
All new point/face identities, join proposals, rejection reasons, camera assumptions, full evaluation rows, logs and candidate models are retained here.
These models are incomplete conditional observations. No hidden geometry, target reference mesh, credentials or unrelated private files are included.
